from flask import Flask, jsonify
from models import Session, EmailStatus  # Import session and EmailStatus model

app = Flask(__name__)

@app.route('/email-status', methods=['GET'])
def get_email_status():
    session = Session()
    email_statuses = session.query(EmailStatus).all()

    response = []
    for status in email_statuses:
        response.append({
            'email': status.recipient_email,
            'status': status.status,
            'timestamp': status.timestamp
        })
    
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
