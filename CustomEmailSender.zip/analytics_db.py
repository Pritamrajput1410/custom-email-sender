from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

# Base class for model definitions
Base = declarative_base()

class EmailStatus(Base):
    __tablename__ = 'email_statuses'

    id = Column(Integer, primary_key=True)
    recipient_email = Column(String, nullable=False)
    status = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)  # Timestamp when the email status was recorded

# Manually connect to SQLite database
DATABASE_URL = "sqlite:///scheduler_jobs.db"
engine = create_engine(DATABASE_URL, echo=True)
Session = sessionmaker(bind=engine)

# Create all tables if they don't exist
def init_db():
    Base.metadata.create_all(engine)

# Add a new email status to the database
def add_email_status(session, recipient_email, status):
    email_status = EmailStatus(
        recipient_email=recipient_email,
        status=status,
        timestamp=datetime.utcnow()
    )
    session.add(email_status)
    session.commit()

# Retrieve email status counts
def get_email_status_count(session, status):
    return session.query(EmailStatus).filter(EmailStatus.status == status).count()

# Close the session after use
def close_session(session):
    session.close()
