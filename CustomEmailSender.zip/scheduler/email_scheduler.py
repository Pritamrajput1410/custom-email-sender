from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.triggers.date import DateTrigger
from email_sender.email_integration import connect_smtp, send_custom_email
from llm.llm_api import generate_custom_message
from analytics_db import Session, add_email_status, close_session
import pandas as pd

# Initialize the scheduler with a database-backed job store (SQLite)
jobstores = {
    "default": SQLAlchemyJobStore(url="sqlite:///scheduler_jobs.db")  # SQLite as the job store
}

scheduler = BackgroundScheduler(jobstores=jobstores)

def send_email_job(data, user_prompt, sender_email, password, smtp_server, smtp_port):
    """Function to send scheduled emails."""
    try:
        session = Session()
        server = connect_smtp(sender_email, password, smtp_server, smtp_port)

        for _, row in data.iterrows():
            row_data = row.to_dict()
            # Generate custom email content using Groq API
            email_body = generate_custom_message(user_prompt, row_data)
            recipient_email = row["Email"]
            
            try:
                send_custom_email(server, sender_email, recipient_email, "Custom Subject", email_body)
                add_email_status(session, recipient_email, 'Sent')  # Mark as sent
                print(f"Email sent to {recipient_email}")
            except Exception as e:
                add_email_status(session, recipient_email, 'Failed')  # Mark as failed
                print(f"Error sending email to {recipient_email}: {e}")

        server.quit()
        close_session(session)
    except Exception as e:
        print(f"Error in send_email_job: {e}")

def schedule_email_send(data, user_prompt, sender_email, password, smtp_server, smtp_port, schedule_time):
    """Schedule email sending job at a specific time."""
    scheduler.add_job(
        send_email_job,
        DateTrigger(run_date=schedule_time),  # Specific time to send the email
        args=[data, user_prompt, sender_email, password, smtp_server, smtp_port],
        id="send_email_job",
        replace_existing=True,
    )
    print(f"Scheduled email sending at {schedule_time}.")
    
def start_scheduler():
    """Start the email scheduler."""
    scheduler.start()

def stop_scheduler():
    """Stop the email scheduler."""
    scheduler.shutdown()
