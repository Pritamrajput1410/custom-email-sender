from groq import Groq
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def generate_custom_message(user_prompt: str, row_data: dict) -> str:
    """
    Generates a custom message by dynamically replacing placeholders in the template with row data.
    """
    # Fetch the API key from the environment
    api_key = os.getenv("GROQ_API_KEY")
    if api_key is None:
        raise ValueError("API key is missing. Please ensure it's in your .env file.")

    # Replace placeholders with row data
    formatted_prompt = user_prompt.format(**row_data)

    # Initialize the Groq client with the API key
    client = Groq(api_key=api_key)

    try:
        # Make the API request to Groq to generate a message
        chat_completion = client.chat.completions.create(
            messages=[{"role": "user", "content": formatted_prompt}],
            model="llama3-8b-8192",
            stream=False,
        )

        # Return the generated message
        return chat_completion.choices[0].message.content

    except Exception as e:
        print(f"Error generating message: {e}")
        return None