def generate_email(template: str, row_data: dict) -> str:
    """
    Replace placeholders in the email template with data from the row.
    Example:
    template: "Hello {Company Name}, your location is {Location}."
    row_data: {"Company Name": "Acme Corp", "Location": "NYC"}
    """
    try:
        return template.format(**row_data)
    except KeyError as e:
        missing_field = str(e).strip("'")
        raise ValueError(f"Placeholder '{missing_field}' not found in the dataset columns.")