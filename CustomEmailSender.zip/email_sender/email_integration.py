import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle

def connect_smtp(email: str, password: str, smtp_server: str, smtp_port: int):
    """Connect to an SMTP server."""
    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(email, password)
    return server

def send_email(server, sender_email, recipient_email, subject, body):
    """Send an email using an SMTP server."""
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    server.sendmail(sender_email, recipient_email, msg.as_string())
def send_custom_email(server, sender_email, recipient_email, subject, body):
    """
    Sends an email with the given content.
    """
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    # Create the email
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = recipient_email
    message["Subject"] = subject

    # Add the email body
    message.attach(MIMEText(body, "plain"))

    # Send email
    server.sendmail(sender_email, recipient_email, message.as_string())