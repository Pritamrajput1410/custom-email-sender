from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.triggers.date import DateTrigger
from data.data_loader import load_csv, connect_google_sheet, get_column_names
from email_sender.email_integration import connect_smtp, send_custom_email
from llm.llm_api import generate_custom_message
import time
import os
from dotenv import load_dotenv
import smtplib
import pandas as pd
from analytics_dashboard import start_analytics_scheduler
from scheduler.email_scheduler import schedule_email_send

# Load environment variables from .env file
load_dotenv()

# Initialize the scheduler with a database-backed job store (SQLite)
jobstores = {
    "default": SQLAlchemyJobStore(url="sqlite:///scheduler_jobs.db")
}

scheduler = BackgroundScheduler(jobstores=jobstores)

def main():
    # Step 1: Load dataset
    choice = input("Choose data source (1: CSV, 2: Google Sheet): ")
    if choice == "1":
        file_path = input("Enter the path to the CSV file: ")
        data = load_csv(file_path)
    elif choice == "2":
        sheet_url = input("Enter the Google Sheet URL: ")
        credentials_file = input("Enter the path to the credentials JSON file: ")
        data = connect_google_sheet(sheet_url, credentials_file)
    else:
        print("Invalid choice. Exiting.")
        return

    # Step 2: Display detected columns
    column_names = get_column_names(data)
    print("Detected columns in the dataset: ")
    print(", ".join(column_names))

    # Step 3: User Inputs
    print("\nUse placeholders in the template by wrapping column names in curly braces (e.g., {ColumnName}).")
    user_prompt = input("Enter the email template prompt: ")

    # Email connection
    sender_email = input("Enter your email address: ")
    password = input("Enter your email password: ")
    smtp_server = "smtp.gmail.com"
    smtp_port = 587

    # Step 4: Ask user for scheduling preferences
    schedule_choice = input("Would you like to schedule emails? (y/n): ")
    if schedule_choice.lower() == "y":
        schedule_time_str = input("Enter the time (HH:MM:SS) to send emails: ")
        schedule_time = pd.to_datetime(schedule_time_str, format='%H:%M:%S').time()
        schedule_email_send(data, user_prompt, sender_email, password, smtp_server, smtp_port, schedule_time)
    
    # Start the analytics and email scheduler
    start_analytics_scheduler()
    scheduler.start()

    try:
        while scheduler.get_jobs():
            time.sleep(1)  # Keep the main program running while the scheduler operates
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
        print("Scheduler stopped.")

if __name__ == "__main__":
    main()
