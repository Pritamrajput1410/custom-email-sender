from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

Base = declarative_base()

class EmailStatus(Base):
    __tablename__ = 'email_statuses'
    
    id = Column(Integer, primary_key=True)
    recipient_email = Column(String, nullable=False)
    status = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

# Database URL (Adjust if needed)
DATABASE_URL = "sqlite:///emails.db"  # SQLite database

# Create a new session and engine to interact with the database
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
Session = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create all tables in the database
Base.metadata.create_all(bind=engine)
