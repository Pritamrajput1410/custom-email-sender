import pandas as pd
import gspread
from oauth2client.service_account import ServiceAccountCredentials

def load_csv(file_path: str) -> pd.DataFrame:
    """Load data from a CSV file."""
    return pd.read_csv(file_path)

def connect_google_sheet(sheet_url: str, credentials_file: str) -> pd.DataFrame:
    """Connect to a Google Sheet and fetch its data."""
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name(credentials_file, scope)
    client = gspread.authorize(creds)
    sheet = client.open_by_url(sheet_url).sheet1
    data = sheet.get_all_records()
    return pd.DataFrame(data)
def get_column_names(dataframe) -> list:
    """
    Returns a list of column names from the dataframe.
    """
    return list(dataframe.columns)