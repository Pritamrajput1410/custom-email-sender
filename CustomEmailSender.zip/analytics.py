from flask import Flask, jsonify
import sqlite3

DB_PATH = "scheduler_jobs.db"
app = Flask(__name__)

@app.route("/analytics", methods=["GET"])
def get_analytics():
    """Fetch analytics data."""
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM email_status WHERE status = 'sent'")
        total_sent = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM email_status WHERE status = 'pending'")
        pending = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM email_status WHERE status = 'scheduled'")
        scheduled = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM email_status WHERE status = 'failed'")
        failed = cursor.fetchone()[0]

    return jsonify({
        "total_sent": total_sent,
        "pending": pending,
        "scheduled": scheduled,
        "failed": failed
    })

if __name__ == "__main__":
    app.run(debug=True)
