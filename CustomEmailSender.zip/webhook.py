from flask import Flask, request, jsonify
from models import Session, EmailStatus  # Import session and EmailStatus model
import json

app = Flask(__name__)

@app.route('/sendgrid-webhook', methods=['POST'])
def sendgrid_webhook():
    try:
        events = request.get_json()  # Get the list of events from SendGrid
        
        # Create a session to interact with the database
        session = Session()

        for event in events:
            email = event.get('email')
            event_type = event.get('event')  # event types: 'delivered', 'opened', 'bounced', etc.

            # Map event type to the corresponding status
            status = "Sent"  # Default status
            if event_type == 'delivered':
                status = "Delivered"
            elif event_type == 'bounce':
                status = "Bounced"
            elif event_type == 'open':
                status = "Opened"
            elif event_type == 'failed':
                status = "Failed"
            
            # Insert or update email status in the database
            email_status = EmailStatus(
                recipient_email=email,
                status=status,
                timestamp=event.get('timestamp')
            )
            session.add(email_status)
        
        session.commit()  # Commit changes to the database
        return jsonify({"status": "success"}), 200
    
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5000)
