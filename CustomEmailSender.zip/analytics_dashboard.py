from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.triggers.interval import IntervalTrigger
from analytics_db import Session, add_email_status, close_session, get_email_status_count, init_db
import time

# Initialize the scheduler with a database-backed job store (SQLite)
jobstores = {
    "default": SQLAlchemyJobStore(url="sqlite:///scheduler_jobs.db")  # SQLite as the job store
}

scheduler = BackgroundScheduler(jobstores=jobstores)

def update_analytics():
    """Background job to update email status metrics regularly."""
    try:
        session = Session()
        sent_count = get_email_status_count(session, 'Sent')
        failed_count = get_email_status_count(session, 'Failed')
        pending_count = get_email_status_count(session, 'Pending')

        print(f"Total Emails Sent: {sent_count}")
        print(f"Emails Pending: {pending_count}")
        print(f"Emails Failed: {failed_count}")
        close_session(session)
    except Exception as e:
        print(f"Error updating analytics: {e}")

def start_analytics_scheduler():
    """Start the background job to update analytics every 5 minutes."""
    scheduler.add_job(
        update_analytics,
        IntervalTrigger(minutes=5),  # Adjust interval as needed
        id="update_analytics_job",  # Job ID
        replace_existing=True,  # Replace the existing job if re-scheduled
    )
    print("Scheduled analytics update every 5 minutes.")
    scheduler.start()

def stop_analytics_scheduler():
    """Stop the background job."""
    scheduler.shutdown()
